# The-Basic-Classification-of-Thyroid-Tumors-on-UltraSound-Images-using-Deep-Learning-Methods

The Basic Usage - Upload "ipyb" file to Google Colab and run. That's it.


#### [The Medium Article ](https://serdarhelli.medium.com/the-basic-classification-of-thyroid-tumors-on-ultrasound-images-using-deep-learning-methods-46f812d859ea)

### The DataSet

[Colombia National University presented an open access database of thyroid ultrasound images.](http://cimalab.intec.co/applications/thyroid/index.php)




  

  

  
  

 
